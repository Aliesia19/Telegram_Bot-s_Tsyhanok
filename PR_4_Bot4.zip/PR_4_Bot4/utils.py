def get_zodiac_sign(day: int, month: int):
    if (month == 3 and day >= 21) or (month == 4 and day <= 19):
        return "Овен"
    if (month == 4 and day >= 20) or (month == 5 and day <= 20):
        return "Телець"
    if (month == 5 and day >= 21) or (month == 6 and day <= 20):
        return "Близнюки"
    if (month == 6 and day >= 21) or (month == 7 and day <= 22):
        return "Рак"
    if (month == 7 and day >= 23) or (month == 8 and day <= 22):
        return "Лев"
    if (month == 8 and day >= 23) or (month == 9 and day <= 22):
        return "Діва"
    if (month == 9 and day >= 23) or (month == 10 and day <= 22):
        return "Терези"
    if (month == 10 and day >= 23) or (month == 11 and day <= 21):
        return "Скорпіон"
    if (month == 11 and day >= 22) or (month == 12 and day <= 21):
        return "Стрілець"
    if (month == 12 and day >= 22) or (month == 1 and day <= 19):
        return "Козеріг"
    if (month == 1 and day >= 20) or (month == 2 and day <= 18):
        return "Водолій"
    if (month == 2 and day >= 19) or (month == 3 and day <= 20):
        return "Риби"
    return None
