import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from config import TELEGRAM_TOKEN
import database
from handlers import main_router, payment_router

logging.basicConfig(level=logging.INFO)

async def main():
    await database.init_db()
    
    bot = Bot(token=TELEGRAM_TOKEN)
    dp = Dispatcher()
    
    # Підключаємо всі роутери
    dp.include_router(main_router)
    dp.include_router(payment_router)

    @dp.message(Command("start"))
    async def start(message: Message):
        await message.answer(
            "Вітаю! Я бот для керування балансом 💳\n"
            "Використайте /register для реєстрації, /balance для перегляду балансу та /topup для поповнення."
        )

    try:
        logging.info("Запуск бота...")
        await dp.start_polling(bot)
    except asyncio.CancelledError:
        logging.info("Polling cancelled, бот зупинено")
    except Exception as e:
        logging.error(f"Помилка під час запуску: {e}")

if __name__ == "__main__":
    asyncio.run(main())
