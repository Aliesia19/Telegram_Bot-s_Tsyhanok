import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from config import TELEGRAM_TOKEN
from handlers import router
from keyboards import main_keyboard

logging.basicConfig(level=logging.INFO)

bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher()
dp.include_router(router)  # підключаємо наші хендлери

# Базові команди
@dp.message(Command("start"))
async def start(message: Message):
    await message.answer(
        "Вітаю! Я бот для замовлення верхнього одягу 👕",
        reply_markup=main_keyboard
    )

@dp.message(Command("help"))
async def help_command(message: Message):
    await message.answer(
        "/start - почати роботу\n/help - допомога\n/info - інформація"
    )

@dp.message(Command("info"))
async def info_command(message: Message):
    await message.answer(
        "Тут ти можеш замовити куртки, светри та інший верхній одяг!"
    )

if __name__ == "__main__":
    asyncio.run(dp.start_polling(bot))
