import random
import asyncio
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
import database

router = Router()

# Стан користувачів, які натиснули /topup
PENDING_TOPUP = {}  # {user_id: True}

@router.message(Command("topup"))
async def topup(message: Message):
    """
    Користувач натискає /topup.
    Бот чекає наступного повідомлення з сумою.
    """
    user_id = message.from_user.id
    PENDING_TOPUP[user_id] = True
    await message.answer(
        "Введіть суму для поповнення. Наприклад: 1000\n"
        "Або використайте /topup <сума> одразу."
    )

@router.message(lambda message: message.text.startswith("/topup "))
async def topup_process(message: Message):
    """
    Користувач вводить /topup <сума> одразу.
    """
    try:
        parts = message.text.split()
        if len(parts) < 2:
            await message.answer("Вкажіть суму після /topup, наприклад /topup 100")
            return

        amount = float(parts[1])
        if amount <= 0:
            await message.answer("Сума повинна бути більшою за 0.")
            return

        user_id = message.from_user.id
        await message.answer(f"Ініціація платежу на {amount} грн... ⏳")

        # Симуляція затримки платежу
        await asyncio.sleep(2)

        # Симуляція результату платежу: успішний або невдалий
        payment_success = random.choice([True, True, False])  # 2/3 шанс успіху
        if payment_success:
            await database.update_balance(user_id, amount)
            await message.answer(f"✅ Платіж успішний! Баланс поповнено на {amount} грн")
        else:
            await message.answer("❌ Платіж не пройшов. Спробуйте ще раз.")

        # Якщо була попередня команда /topup, скидаємо стан
        PENDING_TOPUP[user_id] = False

    except ValueError:
        await message.answer("Невірний формат. Використайте /topup 100")
    except Exception as e:
        await message.answer(f"Помилка при обробці платежу: {e}")

@router.message(lambda message: message.text.isdigit())
async def topup_direct(message: Message):
    """
    Користувач вводить тільки число після команди /topup.
    """
    user_id = message.from_user.id
    if PENDING_TOPUP.get(user_id):
        try:
            amount = float(message.text)
            if amount <= 0:
                await message.answer("Сума повинна бути більшою за 0.")
                return

            await message.answer(f"Ініціація платежу на {amount} грн... ⏳")
            await asyncio.sleep(2)

            payment_success = random.choice([True, True, False])
            if payment_success:
                await database.update_balance(user_id, amount)
                await message.answer(f"✅ Платіж успішний! Баланс поповнено на {amount} грн")
            else:
                await message.answer("❌ Платіж не пройшов. Спробуйте ще раз.")

        except Exception as e:
            await message.answer(f"Помилка при обробці платежу: {e}")

        # скидаємо стан користувача
        PENDING_TOPUP[user_id] = False
