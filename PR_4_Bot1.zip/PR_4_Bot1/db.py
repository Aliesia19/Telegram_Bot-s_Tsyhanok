import sqlite3

DB_PATH = "pc_store.db"

# Підключення до бази
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ---- Користувачі ----
def ensure_user(user):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT OR IGNORE INTO users (id, username, first_name, last_name) VALUES (?, ?, ?, ?)",
        (user.id, user.username, user.first_name, user.last_name)
    )
    conn.commit()
    conn.close()

# ---- Товари ----
def list_products():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products")
    rows = cur.fetchall()
    conn.close()
    return rows

def get_product(product_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    row = cur.fetchone()
    conn.close()
    return row

# ---- Корзина ----
def add_to_cart(user_id, product_id, qty=1):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, qty FROM cart WHERE user_id=? AND product_id=?", (user_id, product_id))
    row = cur.fetchone()
    if row:
        cur.execute("UPDATE cart SET qty = qty + ? WHERE id = ?", (qty, row["id"]))
    else:
        cur.execute("INSERT INTO cart (user_id, product_id, qty) VALUES (?, ?, ?)", (user_id, product_id, qty))
    conn.commit()
    conn.close()

def get_cart(user_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""SELECT c.id, c.product_id, c.qty, p.name, p.price 
                   FROM cart c JOIN products p ON c.product_id = p.id
                   WHERE c.user_id = ?""", (user_id,))
    rows = cur.fetchall()
    conn.close()
    return rows

def clear_cart(user_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM cart WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

# ---- Замовлення ----
def create_order_from_cart(user_id):
    cart = get_cart(user_id)
    if not cart:
        return None
    total = sum(row["qty"] * row["price"] for row in cart)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO orders (user_id, total) VALUES (?, ?)", (user_id, total))
    order_id = cur.lastrowid
    for row in cart:
        cur.execute("INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)",
                    (order_id, row["product_id"], row["qty"], row["price"]))
    conn.commit()
    conn.close()
    clear_cart(user_id)
    return order_id
