from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import db  # твій модуль для роботи з SQLite

TOKEN = "8220195323:AAGCeVEqbeH9NXUBH8BJRRdgLVlmuLfjjyw"

# Головне меню
main_menu = [
    ["🖥 Допомога", "🛒 Замовити техніку"],
    ["🛒 Моя корзина", "ℹ️ Про нас"]
]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Вітаю! Я бот магазину комп'ютерної техніки 💻\nВиберіть дію:",
        reply_markup=ReplyKeyboardMarkup(main_menu, resize_keyboard=True)
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user = update.effective_user
    db.ensure_user(user)

    if text == "🖥 Допомога":
        await update.message.reply_text("Я можу допомогти вам вибрати техніку або оформити замовлення.")
    
    elif text == "🛒 Замовити техніку":
        products = db.list_products()
        if not products:
            await update.message.reply_text("Товари ще не додані.")
            return
        msg = "Оберіть товар, написавши його номер:\n"
        for p in products:
            msg += f"{p['id']}. {p['name']} — {p['price']} UAH\n"
        await update.message.reply_text(msg)

    elif text.isdigit():
        product = db.get_product(int(text))
        if product:
            db.add_to_cart(user.id, product["id"])
            await update.message.reply_text(f"{product['name']} додано у корзину ✅")
        else:
            await update.message.reply_text("Товар не знайдено!")

    elif text == "🛒 Моя корзина":
        cart = db.get_cart(user.id)
        if not cart:
            await update.message.reply_text("Корзина порожня.")
            return
        msg = "Ваша корзина:\n"
        for c in cart:
            msg += f"{c['name']} x{c['qty']} — {c['price']} UAH\n"
        total = sum(c['qty']*c['price'] for c in cart)
        msg += f"\nРазом: {total} UAH\nНапишіть 'Оформити', щоб зробити замовлення."
        await update.message.reply_text(msg)

    elif text.lower() == "оформити":
        order_id = db.create_order_from_cart(user.id)
        if order_id:
            await update.message.reply_text(f"Замовлення #{order_id} прийнято! ✅")
        else:
            await update.message.reply_text("Корзина порожня!")

    elif text == "ℹ️ Про нас":
        await update.message.reply_text("Магазин комп'ютерної техніки TechStore. Працюємо 24/7!")

    else:
        await update.message.reply_text("Я вас почув! Наш менеджер скоро відповість 😊")

# ----------------------
# Синхронний запуск бота
# ----------------------
import asyncio

if __name__ == "__main__":
    loop = asyncio.new_event_loop()  # створюємо новий цикл
    asyncio.set_event_loop(loop)

    from telegram.ext import Application, CommandHandler, MessageHandler, filters
    import db

    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT, handle_message))

    print("Бот запущений!")
    loop.run_until_complete(app.run_polling())
