import telebot
import requests
from config import TELEGRAM_TOKEN, CURRENCY_API_KEY, CURRENCY_API_URL
import db

bot = telebot.TeleBot(TELEGRAM_TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.send_message(message.chat.id,
                     "Вітаю! Я CurrencyBot 💱\n"
                     "Щоб конвертувати валюту, надішліть повідомлення у форматі:\n"
                     "100 USD в EUR\n"
                     "Де 100 — сума, USD — валюта відправлення, EUR — валюта отримання.\n"
                     "Команди:\n"
                     "/rates - поточні курси основних валют\n"
                     "/history - ваші останні конвертації")

@bot.message_handler(commands=['rates'])
def send_rates(message):
    data = get_rates()
    if data:
        msg = "Поточні курси валют (до USD):\n"
        for curr in ['EUR', 'GBP', 'UAH', 'JPY', 'CHF']:
            if curr in data:
                msg += f"{curr}: {data[curr]}\n"
        bot.send_message(message.chat.id, msg)
    else:
        bot.send_message(message.chat.id, "Не вдалося отримати курси валют ❌")

@bot.message_handler(commands=['history'])
def send_history(message):
    rows = db.get_history(message.from_user.id)
    if rows:
        msg = "Ваша історія конвертацій:\n"
        for r in rows[:10]:  # показати останні 10
            amount, from_curr, to_curr, result, ts = r
            msg += f"{amount} {from_curr} -> {result:.2f} {to_curr} ({ts})\n"
        bot.send_message(message.chat.id, msg)
    else:
        bot.send_message(message.chat.id, "Історія порожня.")

def get_rates(base="USD"):
    try:
        url = f"{CURRENCY_API_URL}/{base}"
        response = requests.get(url)
        data = response.json()
        if data['result'] == 'success':
            return data['rates']
        else:
            return None
    except Exception as e:
        print("Error fetching rates:", e)
        return None

def convert_currency(amount, from_curr, to_curr, rates):
    from_curr = from_curr.upper()
    to_curr = to_curr.upper()
    if from_curr not in rates or to_curr not in rates:
        return None
    # конвертація через базову валюту (USD)
    usd_amount = amount / rates[from_curr]
    result = usd_amount * rates[to_curr]
    return result

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    text = message.text.strip()
    # очікуємо формат "100 USD в EUR"
    try:
        parts = text.split()
        if len(parts) != 4 or parts[2].lower() != 'в':
            raise ValueError
        amount = float(parts[0])
        from_curr = parts[1]
        to_curr = parts[3]
    except:
        bot.send_message(message.chat.id, "Некоректний формат! Використовуйте, наприклад: 100 USD в EUR")
        return

    rates = get_rates()
    if not rates:
        bot.send_message(message.chat.id, "Не вдалося отримати курси валют ❌")
        return

    result = convert_currency(amount, from_curr, to_curr, rates)
    if result is None:
        bot.send_message(message.chat.id, "Введено невідому валюту ❌")
        return

    # Зберігаємо в базі
    db.add_query(message.from_user.id, amount, from_curr, to_curr, result)

    # Надсилаємо користувачу
    bot.send_message(message.chat.id, f"{amount} {from_curr.upper()} = {result:.2f} {to_curr.upper()}")

print("CurrencyBot запущений...")
bot.polling(none_stop=True)
