import sqlite3

DB_NAME = "weather_history.db"

def get_conn():
    """Повертає підключення до бази даних."""
    conn = sqlite3.connect(DB_NAME)
    return conn

def create_table():
    """Створює таблицю history, якщо її ще немає."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS history (
            user_id INTEGER,
            city TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def add_query(user_id, city):
    """Додає запит користувача до таблиці history."""
    create_table()  # переконатися, що таблиця існує
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO history(user_id, city) VALUES (?, ?)", (user_id, city))
    conn.commit()
    conn.close()

def get_history(user_id):
    """Повертає список останніх запитів конкретного користувача."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT city, timestamp FROM history WHERE user_id=? ORDER BY timestamp DESC", (user_id,))
    rows = cur.fetchall()
    conn.close()
    return rows
