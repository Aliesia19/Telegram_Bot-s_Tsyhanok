import telebot
import requests
from datetime import datetime
import db  # твій модуль для роботи з базою

API_KEY = "1e79939179b4f2645d64d2d469cc02ff"
TOKEN = "8597286502:AAGZPVgoxEzOrE415AqVqsPNAqpkQt7D9cY"
bot = telebot.TeleBot(TOKEN)

cities_dict = {
    "Київ": "Kyiv",
    "Львів": "Lviv",
    "Одеса": "Odesa",
    "Харків": "Kharkiv",
    "Дніпро": "Dnipro",
    "Запоріжжя": "Zaporizhzhia",
    "Вінниця": "Vinnytsia",
    "Чернівці": "Chernivtsi",
    "Івано-Франківськ": "Ivano-Frankivsk",
    "Тернопіль": "Ternopil",
    "Луцьк": "Lutsk",
    "Рівне": "Rivne",
    "Житомир": "Zhytomyr",
    "Хмельницький": "Khmelnytskyi",
    "Черкаси": "Cherkasy",
    "Суми": "Sumy",
    "Полтава": "Poltava",
    "Кропивницький": "Kropyvnytskyi",
    "Чернігів": "Chernihiv",
    "Миколаїв": "Mykolaiv",
    "Херсон": "Kherson",
    "Слов'янськ": "Sloviansk"
}

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.send_message(message.chat.id,
                     "Вітаю! Я WeatherBot 🌤\n"
                     "Введіть назву міста латиницею або українською, щоб отримати прогноз погоди.\n"
                     "Наприклад: Kyiv, Lviv або Київ, Львів")

def get_weather(city):
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric&lang=ua"
    response = requests.get(url)
    # Дебаг для перевірки API
    print(response.status_code, response.text)
    
    if response.status_code != 200:
        return None
    
    data = response.json()
    weather_desc = data['weather'][0]['description'].capitalize()
    temp = data['main']['temp']
    wind = data['wind']['speed']
    humidity = data['main']['humidity']
    date = datetime.now().strftime("%d.%m.%Y %H:%M")
    
    msg = (f"Погода в {city}: {date}\n"
           f"Температура: {temp}°C\n"
           f"Опис: {weather_desc}\n"
           f"Вологість: {humidity}%\n"
           f"Швидкість вітру: {wind} м/с")
    return msg

@bot.message_handler(func=lambda message: True)
def send_weather(message):
    city_input = message.text.strip().capitalize()  # прибираємо зайві пробіли і робимо першу літеру великою
    
    # Конвертуємо українські назви в латиницю, якщо є в словнику
    city = cities_dict.get(city_input, city_input)
    
    weather = get_weather(city)
    
    # Зберігаємо запит у базі
    db.add_query(message.from_user.id, city)
    
    if weather:
        bot.send_message(message.chat.id, weather)
    else:
        bot.send_message(message.chat.id,
                         "Місто не знайдено ❌. Перевірте правильність написання або спробуйте інше місто.")

print("WeatherBot запущений...")
bot.polling(none_stop=True)
