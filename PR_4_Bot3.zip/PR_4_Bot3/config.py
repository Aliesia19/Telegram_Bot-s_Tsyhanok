# config.py
TELEGRAM_TOKEN = "8451229872:AAGL_pOyuuQBZd72vn5rucoO-8fHdeEjLN4"
CURRENCY_API_KEY = "92b502c3cce5624155c383ad"
CURRENCY_API_URL = "https://open.er-api.com/v6/latest"  # приклад безкоштовного API
