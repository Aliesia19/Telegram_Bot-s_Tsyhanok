from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
import database

router = Router()

@router.message(Command("register"))
async def register(message: Message):
    await database.add_user(message.from_user.id, message.from_user.username)
    await message.answer("Ви успішно зареєстровані! ✅")

@router.message(Command("balance"))
async def balance(message: Message):
    bal = await database.get_balance(message.from_user.id)
    if bal is not None:
        await message.answer(f"Ваш баланс: {bal} грн 💰")
    else:
        await message.answer("Ви ще не зареєстровані. Використайте /register")
