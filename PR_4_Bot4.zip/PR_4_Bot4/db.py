import sqlite3

DB_NAME = "horoscope_history.db"

def get_conn():
    return sqlite3.connect(DB_NAME)

def create_table():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS history (
            user_id INTEGER,
            zodiac_sign TEXT,
            date TEXT,
            horoscope TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def add_query(user_id, zodiac_sign, date, horoscope):
    create_table()
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO history(user_id, zodiac_sign, date, horoscope) VALUES (?, ?, ?, ?)",
        (user_id, zodiac_sign, date, horoscope)
    )
    conn.commit()
    conn.close()

def get_history(user_id):
    create_table()
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT zodiac_sign, date, horoscope, timestamp FROM history WHERE user_id=? ORDER BY timestamp DESC",
        (user_id,)
    )
    rows = cur.fetchall()
    conn.close()
    return rows
