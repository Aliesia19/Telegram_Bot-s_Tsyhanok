from aiogram import Router
from aiogram.types import Message, CallbackQuery
from keyboards import jacket_inline, sweater_inline
from config import WEATHER_API_KEY
import requests

router = Router()

# ReplyKeyboard кнопки через lambda
@router.message(lambda message: message.text == "Замовити куртку")
async def order_jacket(message: Message):
    await message.answer("Оберіть куртку:", reply_markup=jacket_inline)

@router.message(lambda message: message.text == "Замовити светр")
async def order_sweater(message: Message):
    await message.answer("Оберіть светр:", reply_markup=sweater_inline)

@router.message(lambda message: message.text == "Показати погоду")
async def show_weather(message: Message):
    city = "Kyiv"
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric&lang=ua"
    response = requests.get(url).json()
    if response.get("main"):
        temp = response["main"]["temp"]
        desc = response["weather"][0]["description"]
        await message.answer(f"Погода в {city}: {temp}°C, {desc}")
    else:
        await message.answer("Не вдалося отримати погоду 😢")

# Inline кнопки
@router.callback_query()
async def handle_inline(call: CallbackQuery):
    if call.data.startswith("jacket"):
        await call.message.answer(f"Ви обрали: {call.data.replace('_',' ')} ✅")
    elif call.data.startswith("sweater"):
        await call.message.answer(f"Ви обрали: {call.data.replace('_',' ')} ✅")
    await call.answer()

# Обробка фото
@router.message(lambda message: message.photo)
async def handle_photo(message: Message):
    await message.answer("Фото отримано! Дякуємо 😎")
