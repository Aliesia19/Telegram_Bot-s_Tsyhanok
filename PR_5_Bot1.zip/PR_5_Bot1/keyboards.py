from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

# ReplyKeyboard
main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Замовити куртку"), KeyboardButton(text="Замовити светр")],
        [KeyboardButton(text="Показати погоду")]
    ],
    resize_keyboard=True
)

# Inline кнопки для курток
jacket_inline = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Зимова куртка", callback_data="jacket_winter"),
            InlineKeyboardButton(text="Демісезонна куртка", callback_data="jacket_midseason")
        ]
    ]
)

# Inline кнопки для светрів
sweater_inline = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Светр з вовни", callback_data="sweater_wool"),
            InlineKeyboardButton(text="Светр акрил", callback_data="sweater_acrylic")
        ]
    ]
)
