import sqlite3

DB_NAME = "currency_history.db"

def get_conn():
    return sqlite3.connect(DB_NAME)

def create_table():
    """Створює таблицю для історії конвертацій."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS history (
            user_id INTEGER,
            amount REAL,
            from_currency TEXT,
            to_currency TEXT,
            result REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def add_query(user_id, amount, from_curr, to_curr, result):
    create_table()
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO history(user_id, amount, from_currency, to_currency, result) VALUES (?, ?, ?, ?, ?)",
                (user_id, amount, from_curr.upper(), to_curr.upper(), result))
    conn.commit()
    conn.close()

def get_history(user_id):
    """Повертає список останніх запитів конкретного користувача."""
    create_table()  # переконатися, що таблиця існує
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT amount, from_currency, to_currency, result, timestamp FROM history WHERE user_id=? ORDER BY timestamp DESC",
                (user_id,))
    rows = cur.fetchall()
    conn.close()
    return rows
