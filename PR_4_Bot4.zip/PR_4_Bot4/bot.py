import telebot
import json
from datetime import datetime
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

from config import TELEGRAM_TOKEN
import db
from utils import get_zodiac_sign

bot = telebot.TeleBot(TELEGRAM_TOKEN)

with open("horoscope.json", "r", encoding="utf-8") as f:
    HOROSCOPES = json.load(f)

ZODIAC_SIGNS = list(HOROSCOPES.keys())

def get_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = [KeyboardButton(sign) for sign in ZODIAC_SIGNS]
    markup.add(*buttons)
    return markup


@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.send_message(
        message.chat.id,
        "Вітаю! Я HoroscopeBot.\n\n"
        "Можете вибрати знак зодіаку з кнопок або ввести дату народження у форматі:\n"
        "дд.мм або дд.мм.рррр\n\n"
        "Команди:\n"
        "/today — гороскоп на сьогодні\n"
        "/history — історія переглядів",
        reply_markup=get_keyboard()
    )


@bot.message_handler(commands=['today'])
def send_today(message):
    bot.send_message(
        message.chat.id,
        "Введіть свій знак зодіаку або дату народження (дд.мм):",
        reply_markup=get_keyboard()
    )


@bot.message_handler(commands=['history'])
def send_history(message):
    rows = db.get_history(message.from_user.id)
    if rows:
        msg = "Ваша історія гороскопів:\n\n"
        for r in rows[:10]:
            zodiac, date, horoscope, ts = r
            msg += f"{date} — {zodiac}: {horoscope}\n\n"
        bot.send_message(message.chat.id, msg)
    else:
        bot.send_message(message.chat.id, "Історія порожня.")


def send_horoscope(message, zodiac):
    horoscope = HOROSCOPES[zodiac]
    date = datetime.now().strftime("%d.%m.%Y")

    db.add_query(message.from_user.id, zodiac, date, horoscope)

    text = (
        f"Гороскоп для {zodiac} на {date}:\n\n"
        f"{horoscope}"
    )

    bot.send_message(message.chat.id, text)


@bot.message_handler(func=lambda message: True)
def handle_input(message):
    text = message.text.strip()

    # 1. Якщо користувач ввів дату
    try:
        if "." in text:
            parts = text.split(".")
            day = int(parts[0])
            month = int(parts[1])
            zodiac = get_zodiac_sign(day, month)

            if zodiac:
                return send_horoscope(message, zodiac)
            else:
                bot.send_message(message.chat.id, "Неможливо визначити знак. Перевірте дату.")
                return
    except:
        pass

    # 2. Якщо ввів знак зодіаку
    zodiac = text.capitalize()
    if zodiac in HOROSCOPES:
        return send_horoscope(message, zodiac)

    # 3. Некоректний ввід
    bot.send_message(
        message.chat.id,
        "Некоректне значення. Виберіть знак з кнопок або введіть дату у форматі дд.мм."
    )


print("HoroscopeBot запущений...")
bot.polling(none_stop=True)
